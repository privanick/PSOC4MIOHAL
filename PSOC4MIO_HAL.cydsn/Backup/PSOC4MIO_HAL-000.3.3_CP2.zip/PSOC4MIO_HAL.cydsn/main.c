/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <trio.h>

#define SYSTICK_EACH_10_HZ  (10u)
#define SYSTICK_EACH_100_HZ (100u)
// Define tick size  10 ms or 100 ms
#define SYSTICK_RELOAD        (CYDEV_BCLK__SYSCLK__HZ / SYSTICK_EACH_10_HZ)
#define SYSTICK_RELOAD_100_HZ (CYDEV_BCLK__SYSCLK__HZ / SYSTICK_EACH_100_HZ)

// Interrupt prototype 
CY_ISR_PROTO(SysTickIsrHandler);
typedef int (FUNC0)(void);
typedef int (FUNC1)(char *s);
typedef int (*PFUNC0)(void);
typedef int (*PFUNC1)(char *s);
typedef int (*PFUNC2)(int argc, char *argv[]);
typedef int (*FUNC3)(int n);
typedef int (*PFUNC3)(int n);
typedef void (*FUNC4)(int argc, char *argp);
//bit routines
/* test if n-th bit in x is set */
#define B_IS_SET(x, n)   (((x) & (1<<(n)))?1:0)

/* set n-th bit in x */
#define B_SET(x, n)      ((x) |= (1<<(n)))

/* unset n-th bit in x */
#define B_CLEAR(x, n)    ((x) &= ~(1<<(n)))

/* toggle n-th bit in x */
#define B_TOGGLE(x, n)   ((x) ^= (1<<(n)))

/////////////////////////////////////////////////////////////////////////////
// EVENT ROUTINES
////////////////////////////////////////////////////////////////////////////

#define V_DEEPSLEEP    1
#define V_SLEEP        2
#define V_GTICK        3
#define V_1SEC         4
#define V_SEC10        5
#define V_DODS         6
#define V_UBUT         7

uint32 GEV;

#define IF_EV_SET(n)      (((GEV) & (1<<(n)))?1:0)
#define EV_SET(n)      ((GEV) |= (1<<(n)))
#define EV_CLEAR(n)    ((GEV) &= ~(1<<(n)))
#define EV_TOGGLE(n)   ((GEV) ^= (1<<(n)))
////////////////////////////////////////////////////////////////////////////////
//                      GLOBAL VARIABLES FOR IO.C                            
////////////////////////////////////////////////////////////////////////////////
char obuf[100];     // Output buffer                                         
char linebuf[100];  // Line buffer used for command line input               
char *cline;		// Points to current position in line buffer             
char *bufpos;       // Points to the current output buffer position          
char *bufbegin;     // Points to the start of the output buffer              
char *obpos;        // Points to the current output buffer position          
char *obb;          // Output buffer begin                                   

// This string contains all the printable/keyable characters used in the kernel       
const char ChkStr[] =
  {
    "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ -+*/%&|^:=()[]$\",.;<>"
  };


///////////////////////////////////////////////////////////////////////////////
//                          IO.c CODE STARTS HERE                            
///////////////////////////////////////////////////////////////////////////////

void init_io(void)
{
obb = obuf;         // Command buffering                                     
obpos = obuf;       // Command buffer position                               
cline = linebuf;    // Command line is the same as the line buffer            
}

void printbuff(void)
{
long r;
long size;
if (obpos == obb)    return;	

size = (long)(obpos - obb);
obpos=obb;
for(r=0;r<size;r++)  console_UartPutChar((long)*(obpos++));
obpos=obb;

}
/*
 * Insert newline into the output buffer
 */
void newline(void)
{

if((long)((obpos) -obb)>=(long)MAXBUF) 	printbuff();

*obpos++ = CR;
*obpos++ = LF;
*obpos = 0;
printbuff();
}


/*
 * Put character in output buffer
 */
void printc(char c)
{
  if ((long)  ((obpos) -obb) >=  (long)MAXBUF) printbuff();
  if (c == 10)
  {
   *obpos++ = LF;
   printbuff();
  }
  else
  {
    *obpos++ = c;
    *obpos = 0;
  }
}

/*
 * Put string in the output buffer
 */
void prints(char *s)
{
  long i=0;

  while(s[i])
  {
    if((long)(obpos - obb) >=  (long)MAXBUF)
      printbuff();

    if(s[i] == 10)
    {
      *obpos++ = LF;
//      *obpos++ = CR;
      i++;
	  printbuff();
    }
    else
      *obpos++ = s[i++];
  }
  *obpos = 0;
}
void backspace(void)
{
console_UartPutChar(8);
console_UartPutChar(' ');
console_UartPutChar(8);
}

void outchar(char c)
{
console_UartPutChar((long)c);
}

void tab(long n)
{
long i=0;

i= (long)(obpos-obb);
while (i<=n)   { *obpos++ = ' '; i++; }
*obpos = 0;
}

////////////////////////////////////////////////////////
// Multifunctional format printing routine
////////////////////////////////////////////////////////
void printn(char b,char s,int n,int nolz)
{
  int i = 0, tel = 0, x = 0;
  unsigned char c, ont = 0;
  long l = 0;
  char digit[12], temp = 0;
  const char digits[] = {"0123456789ABCDEF"};

  if (b == 'b')
  {
    if (s == 'w')
      tel = 15;
    else
      if(s == 'b')
        tel = 7;
      else
        tel = 3;
    for (i=tel;i>=0;i--)
    {
//	if (tel == 3)     x = 4+i;
	if (i<=7) 
		{
        	x = i;
		c = (unsigned char) n;
		}
	else 
		{
		x = i-8;
		c= (unsigned char)( n>>8);
		}
      	temp=(char)('0'+((c>>x)&1));
     	printc(temp);
    }
  }
  if (b == 'x')
  {
    if (s == 'l') tel = 7;
      if (s == 'w') tel = 3;
      if (s == 'b') tel = 1;

    for (i=tel;i>=0;i--)
    {
      l = n;
      c=(unsigned char)((l>>4*i)&0x0f);
      if (nolz == 1)
      {
        if ((c != 0) || (ont == 1) || (i == 0))
        {
          ont = 1;
          printc(digits[c]);
        }
      }
      else
      {
        printc(digits[c]);
      }
    }
  }
  if (b == 'd')
  {
    l = n;
    for (i=0;i<=9;i++)
    {
      n=l%10;
      l=l/10;
      digit[i] = (char)(n +'0');
    }
    for(i=9;i>=0;i--)
    {
      if ((digit[i] != '0') || (ont == 1) || (i == 0))
      {
        ont = 1;
        printc(digit[i]);
      }
    }
  }
}

char buf[20];

char *ntos(int n)
{
int i = 0;
unsigned char ont = 0;
long l = 0;
char digit[12];
//const char digits[] = {"0123456789ABCDEF"};
char *b;

b = buf;
  
l = n;
for (i=0;i<=9;i++)
  {
  n=l%10;
  l=l/10;
  digit[i] = (char)(n +'0');
  }
for(i=9;i>=0;i--)
  {
  if ((digit[i] != '0') || (ont == 1) || (i == 0))
    {
    ont = 1;
    *b++ = digit[i];
    }
  }
*b++ = '\0';
return buf;
}

/////////////////////////////////////////////////////////////////////
// Return pointer to specified character C, within n characters
/////////////////////////////////////////////////////////////////////

char * xstrnchr(char *s,char c,int n)
{
int x=0;
while (x<n)
	{
	if (*s == c) return s;
	s++;
	x++;
	}
return 0;
}

///////////////////////////////////////////////////////////////////////
// Get a line from input device
///////////////////////////////////////////////////////////////////////

int getline(void)
{
  int c;

  c = console_UartGetChar();

  switch(c)
  {
        case 0x100 : return(-1); /* Nothing entered */

        case 27 : return(-2); /* Escape key      */

        case 1  : return(-3); /* <Ctrl A> key    */

        case 8  : /* <Backspace>     */
                       *cline-- = (char)0;
                       *cline = (char)0;
                        backspace();
                        return(0);

        default : /* <Enter>: line ready to be processed */
                  if ((c == CR) | (c == LF))
                  {    
			       *cline = NULC;
			       cline = linebuf;
                   return(1);
                  }
                   /* If valid character, print and put character in line buffer */
                  if(xstrchr((char *)ChkStr,(char)c)!=NULC)
                  {
                    *cline++ = (char)c;
			        *cline = NULC;
                    console_UartPutChar(c);
                    return(0);
                  }
                  else
                    return (-1);
  }
}

////////////////////////////////////////////////////////////////////////////////////////////
// End of IO.c 
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
// Low level HW BIOS routines dependent on TopDesign
/////////////////////////////////////////////////////////////////////////////////////////////
uint8 toggle=0;     // toggle for led flash;
int64 ltime;        // linux time
uint32 wdcount =0;  // counter for Watch Dog timer
uint32 sticks = 0;  // seconds
uint32 gticks = 0;  // global 10 ms ticks
uint8 lticks =0;    // local ticks

void flash_led(void)
{
if (toggle == 1) toggle = 0;
else toggle = 1;
P4_4_Write(toggle);     
}

CY_ISR(UBUT_isr)
{
//uint8 i=0;
//EV_SET(V_1SEC);  

}

CY_ISR(STICKS_isr)
{
//EV_SET(V_1SEC);  

}

CY_ISR(CRDY_isr)
{
//EV_SET(V_1SEC);  

}
////////////////////////////////////////////////////////
// 1 SEC timer interrupt
// Used for the AFTER table
// and ISEC event
///////////////////////////////////////////////////////
typedef struct{
    uint32 secs;
    uint32 load;
    uint8 ev;
    uint8 inuse;
    FUNC0 *f;
} after;
after aftertab_1S[5];
after aftertab_1M[5];
uint8 atsize =5;

///////////////////////////////////////////////////////
// 1 Hz interrupt and after table
// creates delayed Events that fire after so many seconds
// can be repetitive or 1 shot
///////////////////////////////////////////////////////
CY_ISR(sticks_isr)
{
uint8 i=0;
   
sticks++;
//EV_SET(V_1SEC);  
for (i=0;i<=atsize;i++)
  {
  if (aftertab_1S[i].inuse == 1)
    {
    aftertab_1S[i].secs --;
    if (aftertab_1S[i].secs <=0) 
        { 
        //EV_SET(aftertab[i].ev);
        if (aftertab_1S[i].load >= 1 )aftertab_1S[i].secs = aftertab_1S[i].load; 
        else aftertab_1S[i].inuse = 0;
        }
    }
  }
}
//////////////////////////////////////////////////////////////
// SECONDS elayed events
// ev_after routine provides a delayed event facility
// event can be a oneshot or reptitive depending on the lflag 
// value ; 1 = repeat and 0 = oneshot
/////////////////////////////////////////////////////////////

void ev_after1S(int32 secs, int8 ev, int8 lflag)
{
uint8 i;
    
for (i=0;i<5;i++)
  {
  if (aftertab_1S[i].inuse == 0)
    {
    aftertab_1S[i].secs = secs;
    if (lflag == 1) aftertab_1S[i].load = secs;
    else aftertab_1S[i].load = 0;
    aftertab_1S[i].ev = ev ;   
    aftertab_1S[i].inuse = 1;
    }
  }
}

void ev_after1M(int32 msecs, int8 ev, int8 lflag)
{
uint8 i;
    
for (i=0;i<5;i++)
  {
  if (aftertab_1M[i].inuse == 0)
    {
    aftertab_1M[i].secs = msecs;
    if (lflag == 1) aftertab_1M[i].load = msecs;
    else aftertab_1M[i].load = 0;
    aftertab_1M[i].ev = ev ;   
    aftertab_1M[i].inuse = 1;
    }
  }
}
//////////////////////////////////////////////////////////////
// set up a 100 HZ tick from SYSTICK interrupt handler
// This sets the EV_GTICKS event
// IT sets the EV_SEC10 event
// It manages the fast after table
////////////////////////////////////////////////////////////
void ticker(void)
{
uint8 i=0;
    
gticks++;
if (lticks == 10) { lticks = 0; EV_SET(V_SEC10);}
lticks++;
EV_SET(V_GTICK);
 
for (i=0;i<=atsize;i++)
  {
  if (aftertab_1M[i].inuse == 1)
    {
    aftertab_1M[i].secs --;
    if (aftertab_1M[i].secs <=0) 
        { 
        EV_SET(aftertab_1M[i].ev);
        if (aftertab_1M[i].load >= 1 )aftertab_1M[i].secs = aftertab_1M[i].load; 
        else aftertab_1M[i].inuse = 0;
        }
    }
  }
}

void addto_systic_handler(cySysTickCallback f)
{
uint32 i;
for (i = 0u; i < CY_SYS_SYST_NUM_OF_CALLBACKS; ++i)
  {
  if (CySysTickGetCallback(i) == NULL)
    {
    /* Set callback */
    CySysTickSetCallback(i,f);
    break;
    }
  }
}

//////////////////////////////////////////////////////////////
// WDT interrupt and deep sleep support
/////////////////////////////////////////////////////////////
CY_ISR(WDT_isr)
{
/* Clear interrupts state */
CySysWdtClearInterrupt(CY_SYS_WDT_COUNTER1_INT);
CyIntClearPending(9);
//disable timers
CySysWdtDisable(CY_SYS_WDT_COUNTER0_MASK |CY_SYS_WDT_COUNTER1_MASK |CY_SYS_WDT_COUNTER2_MASK );
wdcount++;   
}

//////////////////////////////////////////////////
// GOTO and RECOVER DEEP SLEEP
/////////////////////////////////////////////////
// SET deep sleep period using cascaded counters
// GOTO deepsleep and recover from it
/////////////////////////////////////////////////
// DEEP SLEEP 
// WDT counter 0 is set to count in seconds by using a count of 32000 and 
//is then casacded with Counter 1 to count the seconds. This is the input 
// parameter
// Max delay is 65,536 secs or 18.2 hours
// 1 min    60
// 10 min   600
// 30 min   1,800
// 1 hr     3,600
// 10 hr    36,000
// 12 hr    43,200
///////////////////////////////////////////////////////////////////////
void set_deepsleep(secs)
{
// disable all counters
CySysWdtDisable(CY_SYS_WDT_COUNTER0_MASK |CY_SYS_WDT_COUNTER1_MASK |CY_SYS_WDT_COUNTER2_MASK );
CyDelay(1);
//set up 1 HZ roll over on timer 0
CySysWdtWriteMode(CY_SYS_WDT_COUNTER0,CY_SYS_WDT_MODE_NONE);
CySysWdtWriteMatch(CY_SYS_WDT_COUNTER0,32000);
CySysWdtWriteClearOnMatch(CY_SYS_WDT_COUNTER0, 1u);

// Place timer 0 and 1 in Cascade
CySysWdtWriteCascade(CY_SYS_WDT_CASCADE_01);

/* Set WDT int after so many seconds*/
CySysWdtWriteMatch(CY_SYS_WDT_COUNTER1,secs);
CySysWdtWriteMode(CY_SYS_WDT_COUNTER1,CY_SYS_WDT_MODE_INT);
CySysWdtWriteClearOnMatch(CY_SYS_WDT_COUNTER1, 1u);
	
/* Enable WDT counters 0 and 1 */
CySysWdtEnable(CY_SYS_WDT_COUNTER0_MASK|CY_SYS_WDT_COUNTER1_MASK);
//CySysWdtEnable(CY_SYS_WDT_COUNTER0_MASK);
CyDelay(1);
}

void goto_deepsleep(int32 t)
{
//EV_CLEAR(V_DEEPSLEEP); 
//EV_CLEAR(V_SLEEP); 
set_deepsleep(t); 
//prints("Deep Sleep "); printd(t);prints("s\r\n");
CyDelay(10); 
CySysPmDeepSleep();
// Restore various resources
CySysTickStart();
//Timer_1_Start();
}

int main()
{
///////////////////////////////////////////////
// Set up basic CORTEX system clock for 100 Hz
// ticker is 1 of 5 possibe handlers 
//////////////////////////////////////////////
CySysTickStart();
CySysTickSetReload(SYSTICK_RELOAD_100_HZ);
addto_systic_handler(ticker);
//////////////////////////////////////////////////
// Set up console communcation and UART
// Initialise basic STDIO and print/string library
/////////////////////////////////////////////////
console_Init();
console_Enable();
console_Start();
init_io(); 
////////////////////////////////////////////////
// Install the WDT interrupt for Deepsleep
////////////////////////////////////////////////
wdog_StartEx(WDT_isr);
sticks_StartEx(STICKS_isr);
crdy_StartEx(CRDY_isr);
ubut_StartEx(UBUT_isr);
///////////////////////////////////////////////      


CyGlobalIntEnable; /* Enable global interrupts. */
prints("Hello World \r\n");


    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        /* Place your application code here. */
        CyDelay(1000);
        flash_led();
        
    }
}

/* [] END OF FILE */
